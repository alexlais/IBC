# IBC
ibcusa1.com - IBC Group Website
https://alexlais.github.io/IBC/index.html

Project description:
- Refacture code
- Create mobile friendly version
- Improve "Contact Us" page
- Improve navigation menu
